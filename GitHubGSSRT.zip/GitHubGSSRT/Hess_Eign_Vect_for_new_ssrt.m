function [nx,ny] = Hess_Eign_Vect_for_new_ssrt(I,sigma,th)

%th is the threshold which permits de take only vectors inside the
%structures


[Hxx,Hxy,Hyy] = Im_Hess(I,sigma);

    Hxx = (sigma^2)*Hxx;
    Hxy = (sigma^2)*Hxy;
    Hyy = (sigma^2)*Hyy;
    %

[Lambda]=eign_values_hessian_ssrt(Hxx,Hxy,Hyy);


%  figure;
 %surfl(-Lambda);
%  title('-\lambda_{max}>0');
% axis([1 101 1 101  0 max(-Lambda(:))] );
% figure;
 %imshow(I);hold on;


mag=sqrt(Hxy.^2+(Lambda-Hxx).^2);
nx=Hxy./(mag+eps);
ny=(Lambda-Hxx)./(mag+eps);


%delete all vectors corresponding to lambda_max less than th to make most
%of vectors inside the stucture
%you can change th and see the result in the following figure;
 nx(-Lambda<th)=0;
 ny(-Lambda<th)=0;
%  imshow(mat2gray(I));
%  hold on;
%  quiver(nx,-ny,1,'r');








   


