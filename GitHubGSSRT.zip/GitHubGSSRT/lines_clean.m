function [Rho,Theta] = lines_clean(rho,theta,d)

Rho=rho;
Theta=theta;
Ro=rho;
Tet=theta;
j=1;
N=length(theta);
indices=[];
for i=1:N
 P=[Ro(i) Tet(i)];  
Ro(i)=[];
Tet(i)=[];
Q=[Ro Tet];
Ro=rho;
Tet=theta;    
%city block distance
[a,dist]=find(abs(Ro-P(1))+abs(Tet-P(2))<d);

a(a==i)=[];

% in indices there is the index of the maximum and the index of the too
% close maximum to the first one
if~isempty(a) 
    for k=1:length(a)
         indices(j,1)=a(k);
            indices(j,2)=i;
              j=j+1;
    end
 end


end
i=1;
%merge the maxima
if ~isempty (indices)
while i<=size(indices,1)
    if theta(indices(i,1))>0 || rho(indices(i,1))>0
    theta(indices(i,1))= round(double(theta(indices(i,1))+theta(indices(i,2)))/2);
    rho(indices(i,1))= round(double(rho(indices(i,1))+rho(indices(i,2)))/2);
     theta(indices(i,2))= 0;
    rho(indices(i,2))= 0;
    end
    i=i+1;
end
end
rho(rho==0)=[];
theta(theta==0)=[];
Rho=rho;
Theta=theta;






