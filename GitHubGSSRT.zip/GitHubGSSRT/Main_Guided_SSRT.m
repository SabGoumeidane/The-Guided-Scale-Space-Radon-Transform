%Paper code of "Goumeidane, A.B., Ziou, D. & Nacereddine, N. Guided Scale Space Radon Transform for linear structures detection. SIViP (2024). https://doi.org/10.1007/s11760-024-03071-x"
% using the work achieved in "Djemel Ziou, Nafaa Nacereddine, Aicha Baya Goumeidane. Scale Space Radon Transform. IET Image Process (2021).  https://doi.org/10.1049/ipr2.12180"
%%
close all;
clear all;
th=10; %for the Hessian, high below th is discarded


imagefiles = dir('.\images');
imagefiles([imagefiles.isdir]) = [];
addpath('.\images');
nfiles = length(imagefiles);
for i=1:nfiles
    
    
    
    currentfilename = imagefiles(i).name;
    
    switch currentfilename % set the parameters as in the paper
        case {'5barres_551.png', 'NoisyIMG551200.mat'}
            sig1=6;
            sig2=16;
            sig=10;
            TH=0.2;
            
        case 'passage6.png'
            sig1=3;
            sig2=8;
            sig=10;
            TH=0.2;
            
        case {'v.png', 'lybie.png', 'codeb.png'}
            sig1=3;
            sig2=8;
            sig=5;
            TH=0.2;
            
            
        case {'rail3.png'}
            sig1=3;
            sig2=8;
            sig=5;
            TH=0.12;
            
        case {'lane1.png'}
            sig1=3;
            sig2=8;
            sig=5;
            TH=0.05;
            
            
    end
    
    
    [filepath,name,ext] = fileparts(currentfilename);
    if ext==".png"
        IMG1 = imread(currentfilename);
        IMG=IMG1(:,:,1);
    else
        load('NoisyIMG551200.mat')
        IMG1=IMG;
    end
    if name=="codeb" % only fore this image because the structures should be bright on a dark background
        IMG=255-IMG;
    end
    
    
    %         figure;
    %         imshow(mat2gray(IMG));
    %%
    [iLength, iWidth] = size(IMG);
    iDiag = sqrt(iLength^2 + iWidth^2);
    if mod(ceil(iDiag),2)==0
        iDiag=ceil(iDiag)+1;
    end
    Length = ceil(iDiag - iLength);
    Width = ceil(iDiag - iWidth) ;
    
    size_j=iLength+Length;
    size_i=size_j;
    tic;
    %%
    %hessian
    %first sigma
    
    [nx1,ny1]=Hess_Eign_Vect_for_new_ssrt(double(IMG),sig1,th);
    mag=sqrt(nx1.^2+ny1.^2);
    nx1=nx1./(mag+eps);
    ny1=ny1./(mag+eps);
    
    % reduce boundaries effects by multiplying by ONE
    %         ONE=zeros(size(nx1));
    %         ONE(2*sig1+1:end-2*sig1+1,2*sig1+1:end-2*sig1+1)=1;
    %         nx1=nx1.*ONE;
    %         ny1=ny1.*ONE;
    nx1(isnan(nx1))=0;
    ny1(isnan(ny1))=0;
    
    % imshow(mat2gray(IMG));hold on;
    % quiver(nx1,-ny1,1,'r');
    %second sigma
    
    [nx2,ny2]=Hess_Eign_Vect_for_new_ssrt(double(IMG),sig2,th);
    mag=sqrt(nx2.^2+ny2.^2);
    nx2=nx2./(mag+eps);
    ny2=ny2./(mag+eps);
    %         nx2=nx2.*ONE;
    %         ny2=ny2.*ONE;
    nx2(isnan(nx2))=0;
    ny2(isnan(ny2))=0;
    % figure;
    % imshow(mat2gray(IMG));hold on;
    % quiver(nx2,-ny2,1,'r');
    %% Guided SSRT Gssrt
    THETA=0:190;
    n = length(THETA);
    len_ro=length(radon(double(IMG),1));
    Guided_R = zeros(n,len_ro);
    theta=-deg2rad(THETA);
    gamm=(pi/2+theta);
    
    for i = 1:n
        
        %vector field pointing in the direction of projection
        %diy=sin(gamm(i))*iy;
        %dix=cos(gamm(i))*ix;
        %But as they have same sin and cos no need to use athe whole field
        diy=sin(gamm(i));
        dix=cos(gamm(i));
        
        Gamma_fct=abs(dix*nx1+diy*(-ny1));
        Gamma_fct2=abs(dix*nx2+diy*(-ny2));
        
        %take the average like in the paper
        %Q=((Gamma_fct+Gamma_fct2)/2).^M;
        %Or take the maximum over Gamma_fct and Gamma_fct2....gives better results
        M=1000;
        Max_Gam=Gamma_fct>Gamma_fct2;
        Gamma_fct2(Max_Gam)=Gamma_fct(Max_Gam);
        Q=Gamma_fct2.^M;
        
        Guided_R(i,:)=(radon( double(IMG).*Q, THETA(i)))';
        
    end
    
    %the univariate Gaussian kernel creation g
    alph=1/(sqrt(2*pi)*sig);
    Bet=2*sig^2;
    L=ceil(9*sig);
    if ~mod(L,2)
        L=L+1;
    end
    xg=floor(L/2);
    X=0:L-1;
    g=alph*(exp((-(X-xg).^2)/Bet));
    g=g/sum(g);
    
    % convolution to obtain guided ssrt from guided radon
    Gssrt=conv2(Guided_R,g,'same');
    %% Detecting relevent maxima
    % figure;
    % surfl(Guided_R);
    % title('Guided Radon');
    
    A=size(Gssrt,1);
    B=size(Gssrt,2);
    Y=1:1:A;
    X=1:1:B;
    [XXX, YYY]=meshgrid(X,Y);
    ix = find(imregionalmax(Gssrt,8));
    Max=max(max(Gssrt));
    
    MAX=find(Gssrt(ix)>TH*Max);  % Reject all peaks below TH*Max
    theta=YYY(ix(MAX));
    ro=XXX(ix(MAX));
    srt=Gssrt(ix(MAX));
    theta(theta==1)=-1;
    theta(theta>=182)=-1;
    ro(theta==-1)=[];
    srt(theta==-1)=[];
    theta(theta==-1)=[];
    
    ssrtones=zeros(size(Gssrt));
    % fill with "1" in ssrtones matrix all Gssrt maxima location
    for m=1:length(ro)
        ssrtones(theta(m),ro(m))=1; % to be used later for refining the results by cleaning the maxima
    end
    
    % plot
    %         Y=0:1:A-1;
    %         X=0:1:B-1;
    %         axis on
    %         [XXX, YYY]=meshgrid(X,Y);
    %         figure;
    %         surf(YYY,XXX,double(Gssrt));
    %         hold on;
    %         for j=1:length(ro)
    %             plot3(theta(j)-1,ro(j)-1,srt(j),'r.','MarkerSize',50);
    %
    %         end
    %         axis([0 length(THETA) 0 size_i-1  0 max(Gssrt(:))+30]);
    %         title('Guided SSRT');
    %         xlabel('\theta')
    %         ylabel('\rho');
    %         zlabel('G_SSRT(\rho,\theta) before cleaning');
    %         yticks( [100 200 300 400]);
    %         xticks( [0 45 90 135 180]);
    %         xticklabels({'0','\pi/4','\pi/2', '3\pi/4', '\pi'});
    %         zticks( [0 ceil(max(Gssrt(:))/2) ceil(max(Gssrt(:))) ]);
    
    %  creating a scale space representation of the ssrt maxima by convolving
    %  the Gssrt repetitively by a kernel
    [ro,theta]=ssrt_scale_space(Gssrt,1,ssrtones);
    
    % merge the resulting maxima that are too close to each others
    %(city block distance <dist)
    if numel(ro)>1
        dist=10;
        [ro,theta] = lines_clean(ro,theta,dist);
        srt=0;
    end
    for i=1:length(ro)
        srt(i)=Gssrt(theta(i),ro(i));
    end
    
    
    % Plot the Gssrt with cleaned maxima
    % figure;
    % surf(YYY,XXX,double(Gssrt));
    % hold on;
    % for j=1:length(ro)
    %     plot3(theta(j)-1,ro(j)-1,srt(j),'r.','MarkerSize',50);
    % end
    %
    % axis([0 180 0 size_i-1  0 max(Gssrt(:))+30]);
    %
    % title('Guided SSRT after cleaning');
    % xlabel('\theta')
    % ylabel('\rho');
    % zlabel('GSSRT(\rho,\theta)');
    % yticks( [100 200 300 400]);
    % xticks( [0 45 90 135 180]);
    % xticklabels({'0','\pi/4','\pi/2', '3\pi/4', '\pi'});
    % zticks( [0 ceil(max(Gssrt(:))/2) ceil(max(Gssrt(:))) ]);
    %% Lines computation and drawing
    RoTheta=[ro theta];
    XG=ceil(size_j/2);
    YG=ceil(size_i/2);
    
    
    points=[];
    %
    r=[];
    ang=[];
    rho=0:size_j-1;
    x=[0:1:size_j-1];
    y=[0:1:size_i-1];
    %         [i, j] = size(IMG);
    %         x=0:j;
    %         y=0:i;
    k=1;
    removed=[];
    figure;
    imshow(mat2gray(IMG)); hold on;
    for s=1:size(RoTheta,1)
        
        ro=double((RoTheta(s,1)));
        theta=RoTheta(s,2);
        % the computed ro is the value obtained when rotating the image about
        % its center by theta, where here the detected line represented by (ro,theta) has its equation x=ro and
        % y=-inf~+inf in the rotated the coordinate system, so the point (ro,0) x=ro and y=0 belongs to this line, we want to see what is
        % the coordiates of this point in coordinates sytem of the image
        %  and the an ro named r is computed as r= X_r*cos(theta)+Y_r *sin(theta)
        %  where X_r and Y_r the coordinates of the points x=ro and y=0 in
        %  the image coordinates sytem
        
        %let take the point (ro,0) of the detected line and
        % and get back to the image coordiantes system by rotation and translation
        
        ang(s)=-THETA(theta)/180*pi;
        
        X_r =  (ro-XG)*cos(ang(s)) + -(0-YG)*sin(ang(s)) + XG-ceil(Width/2); % center of orientation should be shifted in the center of the image, where R is the rotation matrix (points - center)*R + center+translation
        Y_r = (ro-XG)*sin(ang(s)) + (0-YG)*cos(ang(s)) + YG-ceil(Length/2);
        r(s)=(X_r.*cos(ang(s))+Y_r.*sin(ang(s)));
        
        if ((abs(r(s))<3*sig2 && mod(RoTheta(s,2),90)<3) || ((abs(r(s))>iLength-3*sig2 ||abs(r(s))>iWidth-3*sig2  ) && mod(RoTheta(s,2),90)<3) )
            removed(k)=s;
            k=k+1;
       end
        
        
    end
    
    %r
    toc;
 
    
    
    
   
    r(removed)=[];% erase vertical or horizontal lines close to the boundaries
    ang(removed)=[];
    
    %plot the detected lines
    for s=1:1:length(r)
        plot(x,-(r(s)-x*cos(-ang(s)))/sin(-ang(s)),'r', 'LineWidth',1.5);
    end
      
    %% endpoints of lines segments representing structures 
    % works only for continues structures with the assuption of the presnce of
    % one structure per line
    % H is the size of gaussian filter to smooth the image
    H=17;
    if name=="lane1" ||name=="rail3" % little bit complicated nead more sophesticated computation
        continue
    end
    [abcisses,coordonnees]=endpoints(IMG,r,ang,H);
    
    
    for i=0:1:length(abcisses)/2-1
        plot(x,-(r(i+1)-x*cos(-ang(i+1)))/sin(-ang(i+1)),'r', 'LineWidth',1.5);
        
        plot([abcisses(i*2+1) abcisses(i*2+2) ],[coordonnees(i*2+1) coordonnees(i*2+2)],'.','MarkerSize',30);
    end
    
end




