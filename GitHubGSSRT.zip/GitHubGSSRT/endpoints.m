function [abcisses,coordonnees]=endpoints(IMG,real_rho,ang,h)
% works only for continues structures with the assuption of the presnce of
% one structure per line
Vector=[];
[m,n]=size(IMG);
H = fspecial('gaussian', [h h], (1/6)*h);
IM = imfilter(IMG,H,'replicate');

coordonnees=[];
abcisses=[];
for s=1:length(real_rho)
    Abcisse=1:n;
    coordonn=-(real_rho(s)-Abcisse*cos(-ang(s)))/sin(-ang(s));
    %delete coordinates that are out of the image
    Abcisse(coordonn<1)=[];
    coordonn(coordonn<1)=[];
    coordonn(coordonn>m)=-1;
    Abcisse(coordonn==-1)=[];
    coordonn(coordonn==-1)=[];
    
    %special processing for angles pi and pi/2
    if mod(ang(s),pi)==0
        coordonn=1:m;
        Abcisse=Abcisse*ones(size(coordonn));
    end
    
    if mod(ang(s),pi/2)==0 && mod(ang(s),pi)~=0 % ang=+-pi/2 +k*pi
        Abcisse=1:n;
        coordonn=coordonn*ones(size(Abcisse));
    end
    
    %profile
    Profile = interp2(double(IM),Abcisse,coordonn,'*linear');
    % figure;
    PROFILE=[zeros(1,20) Profile zeros(1,20)];
   %  plot( PROFILE);
    
    hold on;
    %smooth the profile
    Vec=smooth(smooth(PROFILE,15,'moving'),15);
   %  plot(Vec,'r');hold on;
    %     xx=0:length(Vec)-1;
    %   Grad=gradient(Vec(:)) ./ gradient(xx(:));
    V=diff(Vec);
    % plot(10*V,'m');
    V=V(21:end-20);
    
    %plot(10*Grad,'c');
    
    [val idxval]=findpeaks(-V);
    [pics idxpics]=findpeaks(V);
    [mval idmv]=max(val);
    [mpic idmp]=max(pics);
    
    mvalm=0.3*mval;
    mpicm=0.3*mpic;
    pics(pics<mpicm)=-1;
    val(val<mvalm)=-1;
    idxval(val==-1)=[];
    idxpics(pics==-1)=[];
    pics(pics==-1)=[];
    val(val==-1)=[];
         plot(idxval+20,0,'ro');
         plot(idxpics+20,0,'ro');
    
    % if there are two vals or two consecutifs peaks remove one of them
    
    idvalpic=[idxval' idxpics'];
    idvalpic_ones=[-1*ones(size(idxval')) ones(size(idxpics'))];
    
    [idvalpic idx]=sort(idvalpic);
    idvalpics_ones=idvalpic_ones(idx);
    mk=1;
    while mk<length(idvalpic)
        if idvalpics_ones(mk)==1 && idvalpics_ones(mk+1)==1
            if abs(V(idvalpic(mk)))>abs(V(idvalpic(mk+1)))
                idvalpic(mk+1)=[];
                idvalpics_ones(mk+1)=[];
            else
                idvalpic(mk)=[];
                idvalpics_ones(mk)=[];
            end
            mk=mk-1;
        else
            if idvalpics_ones(mk)==-1 && idvalpics_ones(mk+1)==-1
                if abs(V(idvalpic(mk)))>abs(V(idvalpic(mk+1)))
                    idvalpic(mk+1)=[];
                    idvalpics_ones(mk+1)=[];
                else
                    idvalpic(mk)=[];
                    idvalpics_ones(mk)=[];
                end
                mk=mk-1;
            end
        end
        
        mk=mk+1;
        
        
    end
    % endpoints begin with 1 and finish with -1
    if idvalpics_ones(1)==-1
        idvalpics_ones(1)=[];
        idvalpic(1)=[];
    end
    if idvalpics_ones(end)==1
        idvalpics_ones(end)=[];
        idvalpic(end)=[];
    end
    
    
    srtpoints=idvalpic;
    dist=[srtpoints(2:end) srtpoints(1)]-srtpoints;
    
    srtpoints(abs(dist)<5)=[];% erase too close endpoits
    dist=abs(srtpoints(1:2:end)-srtpoints(2:2:end)); % computing lines segments lengths
    [maxx loc]=max(dist);
    srtpoints=srtpoints(loc*2-1:loc*2);% retain the tallest one
    
    abcisses=[abcisses Abcisse(srtpoints)];
    coordonnees=[ coordonnees coordonn(srtpoints)];
    %
    % end
    
end%





