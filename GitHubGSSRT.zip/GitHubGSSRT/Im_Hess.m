function [Hxx,Hxy,Hyy] = Im_Hess(I,Sigma)


[X,Y]   = ndgrid(-round(3*Sigma):round(3*Sigma));

% construction du filtre
Gaussxx = 1/(2*pi*Sigma^4) * (X.^2/Sigma^2 - 1) .* exp(-(X.^2 + Y.^2)/(2*Sigma^2));
Gaussxy = 1/(2*pi*Sigma^6) * (X .* Y)           .* exp(-(X.^2 + Y.^2)/(2*Sigma^2));
Gaussyy = Gaussxx';

Hxx = imfilter(I,Gaussxx,'conv');
Hxy = imfilter(I,Gaussxy,'conv');
Hyy = imfilter(I,Gaussyy,'conv');
