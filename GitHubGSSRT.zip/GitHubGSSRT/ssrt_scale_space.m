function [rho,theta] = ssrt_scale_space(ssrt,n,ssrt_mat)
 %scale space 3d
 % the size of the kernel is going to be 2*n+1*2*n+1
 [a,b]=size(ssrt);


 
 
 % we prefer to set it to 50
 Niter=50;
  volume=zeros(a,b,Niter+2);
  ssrt_mat1=ssrt_mat;
se=strel("square",3);
% figure;
 [I,J]=find(ssrt_mat);
  Ncurve=length(I);
 Length=zeros(Ncurve,1);
 indices(:,1)=I;
 indices(:,2)=J;
% plot3(J,I,1*ones(size(J)),'b.','markersize',20);
%  hold on;
 volume(:,:,1)=ssrt_mat;
%  
%   a1 = 2*pi;
%  [x, y] = meshgrid(-1:1/double(n):1);
% R = sqrt(x.^2+y.^2); 
% f = (2*besselj(1,a1*R(:))./R(:)).^2; 
% f=reshape(f,size(x)); 
% f(n+1,n+1)=f(n+1,n); 
%f(R>1)=0;
%f=f/sum(f(:));

% gaussian kernel
 f = fspecial('gaussian', 2*n+1, (2*n+1)/6);
 % mesh(x,y,f);


ssrtones=zeros(size(ssrt));
% convolution
 for i=2:Niter+1
ssrt=conv2(ssrt,f,'same');
% surfl(ssrt); hold on;

ix = find(imregionalmax(ssrt));
s=ssrt(ix);
if isempty(ix)
    break;
else
    
ssrtones(ix)=1;
ssrt_mat1=imdilate(ssrt_mat1,se);% to connect the results with the previous ones
ssrtones=ssrtones.*ssrt_mat1;% by intersect the dilataion results with immediate neighborhood 
if isempty(find(ssrtones,1))
    break;
end
volume(:,:,i)=ssrtones; %put results in next level i


%[I,J]=find(ssrtones);
% plot3(J,I,i*ones(size(J)),'r.','markersize',20);
% ylabel('\theta')
% xlabel('\rho');
ssrt_mat1=ssrtones;
ssrtones=zeros(size(ssrt));

end


 end
m=1;
%computing the the lines lengths
for Z=1:Niter+1
    for tet=2:a-1
        for ro=2:b-1
            
          
                
            if volume(tet,ro,Z)==1
                
                if Z==1
                    volume(tet,ro,Z)=m; %the first point in level 0 of each curve (the first ssrt maxima befor convolution) is labelled differently from 1 to the number of first points (number of 3d curves)
                    indices_tet(m)=tet;
                    indices_ro(m)=ro;
                    Length(m)=Length(m)+1;
                    m=m+1;
                else
                        
                   [i,j,z,val]=findND(volume(tet-1:tet+1,ro-1:ro+1,Z-1:Z+1));
               
                   n=val(1);
                   Length(n)=Length(n)+1;
                   volume(tet,ro,Z)=n;
                   
                end
            end
            
        end
    end
end

L=mean(Length);
%clust=Length>L*0.1;
L=0.3*L; 
theta=indices_tet(Length>=L)';
rho=indices_ro(Length>=L)';


 


