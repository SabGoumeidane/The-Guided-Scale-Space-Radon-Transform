function [Lambda2]=eign_values_hessian_ssrt(Hxx,Hxy,Hyy)

m = sqrt((Hxx - Hyy).^2 + 4*Hxy.^2);

Lambda1 = 0.5*(Hxx + Hyy + m);
Lambda2 = 0.5*(Hxx + Hyy - m);


Lambda1(~isfinite(Lambda1)) = 0;
Lambda2(~isfinite(Lambda2)) = 0;
Lambda1(abs(Lambda1) < 1e-4) = 0;
Lambda2(abs(Lambda2) < 1e-4) = 0;
% figure;
% surfl(Lambda1);
% figure;
% surfl(Lambda2);

% Mettre le maximum en valeur absolue dans Lamdda2


Max_lam=abs(Lambda1)>abs(Lambda2);


 
Lambda2(Max_lam)=Lambda1(Max_lam); % Lambda2 is lambda_max

% figure;
% surfl(Lambda2);







